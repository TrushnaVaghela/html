<?php 

$car = array("Celerio","SUV 700","Mercedes","Alto");
echo "First car is ".$car[0];
echo "<br>Second car is ".$car[1];
echo "<br>Third car is ".$car[2];

?>