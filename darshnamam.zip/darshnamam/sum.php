<?php 
   echo "my name is prachi<br>"."I Study in SYBCA<br>";

print("navrachana university<br>").("aaa<br>");

$a = 10;
echo "value of a = ".$a;
?>