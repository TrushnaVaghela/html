<?php 

$e_data = array("eid"=>101,"ename"=>"Prachi Bhavsar");
echo "employee id = ".$e_data["eid"];
echo "<br>";
echo "employee name = ".$e_data["ename"];

//Another way

foreach($e_data as $value)
{
    echo "<br>";
    echo $value;
}

?>