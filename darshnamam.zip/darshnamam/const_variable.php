<?php 
//  first way of constant declaration
define("pi","3.14");

$r = 3;
$h = 1;

$area = 2*pi*$r*$h;

echo "Area of Cylinder = ".$area;

//second way
const e = 2.72;
 $new_value = 2*e;

 echo "<br>Square of the exponent = ".$new_value;

?>