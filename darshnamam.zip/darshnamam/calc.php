<?php 

$a = 20;
$b = 10;

echo "sum = ".$a+$b;
echo "<br>difference = ".$a-$b;
echo "<br>product = ".$a*$b;
echo "<br>division = ".$a/$b;

?>